#ifndef FILESYS_CACHE_H
#define FILESYS_CACHE_H

#include "devices/block.h"

void init_buffer_cache (void);
void close_buffer_cache (void);
void read_buffer_cache (block_sector_t sector, void *target);
void write_buffer_cache (block_sector_t sector, const void *source);

#endif