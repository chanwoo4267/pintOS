#include <debug.h>
#include <string.h>
#include "filesys/filesys.h"
#include "threads/synch.h"
#include "filesys/cache.h"

#define BUFFER_CACHE_SIZE 64


struct buffer_cache_entry_struct 
{
  bool occupied;
  bool access;  
  bool dirty;     
  block_sector_t disk_sector;
  uint8_t buffer[BLOCK_SECTOR_SIZE];
};

static struct lock buffer_cache_lock;
static struct buffer_cache_entry_struct cache[BUFFER_CACHE_SIZE];

void init_buffer_cache (void)
{
  lock_init (&buffer_cache_lock);

  int i;
  for (i=0; i<BUFFER_CACHE_SIZE; i++)
    cache[i].occupied = false;
}

static void flush_buffer_cache (struct buffer_cache_entry_struct *entry)
{
  ASSERT (entry != NULL && entry->occupied == true);
  ASSERT (lock_held_by_current_thread(&buffer_cache_lock));
  
  if (entry->dirty) 
  {
    entry->dirty = false;
    block_write (fs_device, entry->disk_sector, entry->buffer);
  }
}

void close_buffer_cache (void)
{
  lock_acquire (&buffer_cache_lock);

  int i;
  for (i=0; i<BUFFER_CACHE_SIZE; i++)
  {
    if (cache[i].occupied != false)
      flush_buffer_cache(&(cache[i]));
  }

  lock_release (&buffer_cache_lock);
}

static struct buffer_cache_entry_struct* lookup_buffer_cache (block_sector_t sector)
{
  int i;
  for (i=0; i<BUFFER_CACHE_SIZE; i++)
  {
    if (cache[i].occupied != false) 
      if (cache[i].disk_sector == sector)
        return &(cache[i]);
  }
  return NULL;
}

static struct buffer_cache_entry_struct* evict_buffer_cache (void)
{
  ASSERT (lock_held_by_current_thread(&buffer_cache_lock));

  static int clock;
  struct buffer_cache_entry_struct *slot;
  for(clock=0; ; clock++, clock %= BUFFER_CACHE_SIZE)
  {
    if (cache[clock].occupied == false)
      return &(cache[clock]);

    if (cache[clock].access) 
      cache[clock].access = false;
    else 
      break;
  }

  slot = &cache[clock];

  if (slot->dirty) 
    flush_buffer_cache (slot);

  slot->occupied = false;
  return slot;
}

void write_buffer_cache (block_sector_t sector, const void *source)
{
  lock_acquire (&buffer_cache_lock);

  struct buffer_cache_entry_struct *slot = lookup_buffer_cache (sector);
  if (slot == NULL) 
  {
    slot = evict_buffer_cache ();
    ASSERT (slot != NULL && slot->occupied == false);

    block_read (fs_device, sector, slot->buffer);
    slot->occupied = true;
    slot->dirty = false;
    slot->disk_sector = sector;
  }

  memcpy (slot->buffer, source, BLOCK_SECTOR_SIZE);
  slot->dirty = true;
  slot->access = true;
  
  lock_release (&buffer_cache_lock);
}

void read_buffer_cache (block_sector_t sector, void *target)
{
  lock_acquire (&buffer_cache_lock);
  struct buffer_cache_entry_struct *slot = lookup_buffer_cache (sector);

  if (slot == NULL) 
  {
    slot = evict_buffer_cache ();
    ASSERT (slot != NULL && slot->occupied == false);

    block_read (fs_device, sector, slot->buffer);
    slot->occupied = true;
    slot->dirty = false;
    slot->disk_sector = sector;
  }

  memcpy (target, slot->buffer, BLOCK_SECTOR_SIZE);
  slot->access = true;

  lock_release (&buffer_cache_lock);
}