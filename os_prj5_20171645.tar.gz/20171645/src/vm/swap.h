#ifndef VM_SWAP_H
#define VM_SWAP_H

void swap_init();
void swap_in(size_t used_index, void *kaddr);
void swap_out(size_t swap_index, void *kaddr);

#endif