#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
  /* user-defined */
  lock_init(&lock);
}

/* user-defined */
void check_vaddr(void** esp, int n)
{
  int add = 4;
  int i;
  for (i=0; i<n; i++, add += 4)
  {
    if (!is_user_vaddr(esp + add))
      exit(-1);
  }
}

static void
syscall_handler (struct intr_frame *f) 
{
  switch (*(uint32_t *)(f->esp)) {
    case SYS_HALT:
      halt();
      break;
    case SYS_EXIT:
      check_vaddr(f->esp, 1);
      exit(*(uint32_t *)(f->esp + 4));
      break;
    case SYS_EXEC:
      check_vaddr(f->esp, 1);
      f->eax = exec((const char*)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_WAIT:
      check_vaddr(f->esp, 1);
      f->eax = wait((pid_t)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_READ:
      check_vaddr(f->esp, 3);
      f->eax = read((int)*(uint32_t*)(f->esp + 4), (void*)*(uint32_t*)(f->esp + 8), (unsigned)*(uint32_t*)(f->esp + 12));
      break;
    case SYS_WRITE:
      f->eax = write((int)*(uint32_t*)(f->esp + 4), (void*)*(uint32_t*)(f->esp + 8), (unsigned)*((uint32_t*)(f->esp + 12)));
      break;
    case SYS_FIBO:
      check_vaddr(f->esp, 1);
      f->eax = fibonacci(*(int*)(f->esp + 4));
      break;
    case SYS_MAX:
      check_vaddr(f->esp, 4);
      f->eax = max_of_four_int(*(int*)(f->esp + 4), *(int*)(f->esp + 8), *(int*)(f->esp + 12), *(int*)(f->esp + 16));
      break;
    case SYS_CREATE:
      check_vaddr(f->esp, 2);
      f->eax = create((const char*)*(uint32_t*)(f->esp + 4), (unsigned)*(uint32_t*)(f->esp + 8));
      break;
    case SYS_REMOVE:
      check_vaddr(f->esp, 1);
      f->eax = remove((const char*)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_OPEN:
      check_vaddr(f->esp, 1);
      f->eax = open((const char*)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_FILESIZE:
      check_vaddr(f->esp, 1);
      f->eax = filesize((const char*)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_SEEK:
      check_vaddr(f->esp, 2);
      seek((int)*(uint32_t*)(f->esp + 4), (unsigned)*(uint32_t*)(f->esp + 8));
      break;
    case SYS_TELL:
      check_vaddr(f->esp, 1);
      f->eax = tell((int)*(uint32_t*)(f->esp + 4));
      break;
    case SYS_CLOSE:
      check_vaddr(f->esp, 1);
      close((int)*(uint32_t*)(f->esp + 4));
      break;

    default:
      break;
  }
}

void halt(void)
{
  shutdown_power_off();
}

void exit(int status) 
{
  printf("%s: exit(%d)\n", thread_name(), status);
  thread_current()->exit_status = status;

  for(int i=3; i<MAX_FD; i++)
  {
    if (thread_current()->fd[i] == NULL)
      continue;
    close(i);
  }

  thread_exit ();
}

pid_t exec(const char* cmd_line)
{
  return process_execute(cmd_line);
}

int wait(pid_t pid)
{
  return process_wait(pid);
}

int read(int fd, void* buffer, unsigned size)
{
  if (is_user_vaddr(buffer + size) == false)
    exit(-1);

  lock_acquire(&lock);
  
  int idx;

  if (fd == 0)
  {
    for(idx = 0; idx < size; idx++)
      if (((char*)buffer)[idx] == '\0')
        break;
    lock_release(&lock);
    return idx;
  }
  else if (fd > 2)
  {
    if (thread_current()->fd[fd] == NULL)
      exit(-1);
    lock_release(&lock);
    return file_read(thread_current()->fd[fd], buffer, size);
  }

  lock_release(&lock);
  return -1;
}

int write(int fd, const void *buffer, unsigned size) 
{
  if (is_user_vaddr(buffer + size) == false)
    exit(-1);

  lock_acquire(&lock);

  if (fd == 1) 
  {
    putbuf(buffer, size);
    lock_release(&lock);
    return size;
  }
  else if (fd > 2)
  {
    if (thread_current()->fd[fd] == NULL)
    {
      lock_release(&lock);
      exit(-1);
    }
    if (thread_current()->fd[fd]->deny_write == true)
      file_deny_write(thread_current()->fd[fd]);
    lock_release(&lock);
    return file_write(thread_current()->fd[fd], buffer, size);
  }
  lock_release(&lock);
  return -1;
}

int fibonacci(int n)
{
  if (n < 3)
    return 1;
  else return fibonacci(n-1) + fibonacci(n-2);
}

int max_of_four_int(int a, int b, int c, int d)
{
  int result = a;
  if (b > result)
    result = b;
  if (c > result)
    result = c;
  if (d > result)
    result = d;
  return result;
}

bool create(const char* file, unsigned initial_size)
{
  bool return_value = false;
  if (file == NULL)
    exit(-1);

  if (is_user_vaddr(file) == false)
    exit(-1);
  lock_acquire(&lock);
  return_value = filesys_create (file, initial_size);
  lock_release(&lock);
  return return_value;
}

bool remove(const char* file)
{
  bool return_value = false;
  if (file == NULL)
    exit(-1);

  if (is_user_vaddr(file) == false)
    exit(-1);
  
  lock_acquire(&lock);

  return_value = filesys_remove(file);
  lock_release(&lock);
  return return_value;
}

int open(const char* file)
{
  int i;
  if (file == NULL)
    exit(-1);

  if (is_user_vaddr(file) == false)
    exit(-1);

  lock_acquire(&lock);

  struct file* fd = filesys_open(file);
  if (fd == NULL)
  {
    lock_release(&lock);
    return -1;
  }
  for(i=3; i<MAX_FD; i++)
  {
    if (thread_current()->fd[i] == NULL)
    {
      if (strcmp(thread_current()->name, file) == 0)
         file_deny_write(fd);
      thread_current()->fd[i] = fd;
      lock_release(&lock);
      return i;
     }
  }
  lock_release(&lock);
  return -1;
}

int filesize(int fd)
{
  int return_value = -1;
  if (thread_current()->fd[fd] == NULL)
    exit(-1);
  lock_acquire(&lock);
  return_value = file_length(thread_current()->fd[fd]);
  lock_release(&lock);
  return return_value;
}

void seek(int fd, unsigned position)
{
  if (thread_current()->fd[fd] == NULL)
    exit(-1);
  lock_acquire(&lock);
  file_seek(thread_current()->fd[fd], position);
  lock_release(&lock);
}

unsigned tell(int fd)
{
  unsigned return_value = 0;
  if (thread_current()->fd[fd] == NULL)
    exit(-1);
  lock_acquire(&lock);
  return_value = file_tell(thread_current()->fd[fd]);
  lock_release(&lock);
  return return_value;
}

void close(int fd)
{
  if (thread_current()->fd[fd] == NULL)
    exit(-1);
  lock_acquire(&lock);
  struct file* file = thread_current()->fd[fd];
  thread_current()->fd[fd] = NULL;
  file_close(file);
  lock_release(&lock);
}
 
